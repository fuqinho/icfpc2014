#ifndef SIMULATOR_MAPSTORE_H_
#define SIMULATOR_MAPSTORE_H_

#include <vector>
#include <string>

std::vector<std::string> GetMap(std::string id);

#endif
