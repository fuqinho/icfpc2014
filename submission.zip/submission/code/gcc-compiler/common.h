#pragma once

#include <iostream>
#include <algorithm>
#include <cassert>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include <sstream>

#define PP_CAT(a,b) a##b
